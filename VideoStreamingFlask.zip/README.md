# VideoStreamingFlask
Streaming video with the help of Flask and Opencv 

Link to my blog: https://medium.com/datadriveninvestor/video-streaming-using-flask-and-opencv-c464bf8473d6
